---
name: cshell-control
description: 通过 CShell MCP 连接用户指定的机器，操作终端、文件、任务、应用和已授权的扩展能力，或诊断 CShell MCP 接入与权限。
---

# CShell 控制

## 接入

已出现 cshell 工具时直接使用现有连接。首次接入时，在 CShell 偏好设置的 API/MCP 页面启用服务，为客户端选择目标和操作，保存设置。复制界面显示的 MCP 地址和该客户端的令牌。地址通常是本机回环地址，路径为 /mcp，端口以界面为准。客户端使用 Streamable HTTP 和 Authorization Bearer 认证。令牌仅保存在客户端的安全配置或环境变量，不写入技能、聊天或项目。

在 Codex 中可用以下命令注册服务。将 URL 替换为界面显示的地址，事先在启动 Codex 的环境中设置 CSHELL_MCP_TOKEN。安装技能本身不会注册服务或授予权限。

```
codex mcp add cshell --url <MCP地址> --bearer-token-env-var CSHELL_MCP_TOKEN
```

## 使用

1. 按名称使用 list_servers_page 查找授权连接，按返回的游标翻页。操作本机环境用 list_local_targets。重名时核对目标，Windows 主机与 WSL 分别选择。
2. 用 describe_connection 读取当前提供方的能力和参数。需要会话时使用 connect，保留返回的 sessionId。用 discover_capabilities 查当前可调用项目，按实际 schema 使用 invoke_connection 或 invoke_capability。不要从工具名称猜参数或假定扩展已安装。
3. 文件浏览、复制、终端、任务和监控优先使用对应的专用工具。终端输入前确认会话和当前程序。长任务记录任务 ID，通过 task_read 跟进，确认结果后释放。请求超时先检查任务或目标状态，再决定是否重试，避免重复执行。
4. 连接配置、插件、应用更新、会员域名和 DNS 等持久变更按用户指定范围执行，读取变更后的状态。连接凭据交给 CShell 凭据入口处理，复用保存的身份；身份发生变化先核对。结束时只关闭本次创建且已经用完的会话。
5. 工具不可见时先检查客户端是否已连接、插件是否启用。权限不足用 permission_diagnostics 查看缺少的目标或操作；保留用户设置的审批方式。连接失败时报告具体目标、步骤和可用错误信息。

## 工具索引

以下为打包时发现的工具短名，客户端可能显示 cshell 命名空间前缀。新增的工具和动态扩展以当前服务公开的 tools/list、能力发现和参数说明为准。

- account_traffic_read
- application_preferences
- application_update
- claim_member_domain
- connect
- connection_accept
- connection_create
- connection_credentials
- connection_list
- connection_preflight
- connection_probe
- connection_update
- create_member_dns_record
- delete_member_dns_record
- describe_connection
- disconnect
- discover_capabilities
- execute_command
- files_copy_start
- identity_network_configure
- identity_network_list
- invoke_capability
- invoke_connection
- list_files
- list_local_targets
- list_member_dns_records
- list_member_domains
- list_servers
- list_servers_page
- member_site_workflow
- monitor
- permission_diagnostics
- plugin_catalog
- plugin_download
- plugin_manage
- plugins_list
- rename_member_domain
- session_list
- task_cancel
- task_list
- task_read
- task_release
- task_start
- terminal_input
- terminal_read
- terminal_resize
- terminal_state
- update_member_dns_record
